import secrets
print(secrets.token_hex(nbytes=16))